#!/usr/bin/perl
our $directory=();
our $directory1=();
our $directory2=();
our $output=();
our $dirout=();
our $nfg=();#number of family groups
our $nF=();#number of females 
our $nM=();#number of males
our $THIR=();#max internal relatedness
our $THI=();#max pair relatedness
our $THIM=();#mas male pair relatedness
our $THIF=();#max female pair relatedness
our $THG=();#Max Aver Relatedness per Family
our $filetype="y";
our $THIRM=();
our $THIRF=();
our $mingaver=();#Max Aver Relatedness Family Group
our $auto="n";
while (@ARGV){
    $_=shift @ARGV;
    if ($_=~ /^-i$/){$directory=shift @ARGV;}
    elsif($_=~ /^-o$/){$dirout=shift @ARGV;}
    elsif ($_=~ /^-t1$/){$directory1=shift @ARGV;}
    elsif ($_=~ /^-t2$/){$directory2=shift @ARGV;}
    elsif ($_=~ /^-om$/){$output=shift @ARGV;}
    elsif ($_=~ /^-nfg$/){$nfg=shift @ARGV;}
    elsif ($_=~ /^-nf$/){$nF=shift @ARGV;}
    elsif ($_=~ /^-nm$/){$nM=shift @ARGV;}
    elsif ($_=~ /^-ir$/){$THIR=shift @ARGV;}
    elsif ($_=~ /^-pr$/){$THI=shift @ARGV;}
    elsif ($_=~ /^-prf$/){$THIF=shift @ARGV;}
    elsif ($_=~ /^-prm$/){$THIM=shift @ARGV;}
    elsif ($_=~ /^-gr$/){$THG=shift @ARGV;}
    elsif ($_=~ /^-grs$/){$THSG=shift @ARGV;}
    #elsif ($_=~ /^-f$/){$filetype=shift @ARGV;}
    elsif ($_=~ /^-irm$/){$THIRM=shift @ARGV;}
    elsif ($_=~ /^-irf$/){$THIRF=shift @ARGV;}
    elsif ($_=~ /^-afg$/){$mingaver=shift @ARGV;}
    elsif ($_=~ /^-tp$/){$auto=shift @ARGV;}
}
#print "prm = $THIM , prf = $THIF and pr = $THI , tune-up = $auto, file type = $filetype\n";
#print "$directory1\n$directory2\n$output\n$directory\t$dirout\n";
unless ($directory1 eq "" and $directory2 eq ""){
	$filetype="n";
	#print "Hellow Yuma\n";
}
if ($THIRM eq ""){
    $THIRM=$THIR;
    #print "Yuma: $THIRM\n";
}
if ($THIRF eq ""){
    $THIRF=$THIR;
}
if ($THIM eq ""){
    $THIM=$THI;
}
if ($THIF eq ""){
    $THIF=$THI;
}
if ($mingaver eq ""){
    $mingaver=1;
}

print "ir = $THIR , mir = $THIRM , prm = $THIM , prf = $THIF and pr = $THI\ntune-up = $auto, file type = $filetype\n";

if ($directory eq "" and $filetype eq "y"){
    die "Please select a Pairwise Relatedness Matrix as inputfile\n";
}


if ($filetype eq "n"){ 
    chomp $directory1;
    open (IN1, "<$directory1") or die "Can not open table1 $!\n";
    chomp $directory2;
    open (IN2, "<$directory2") or die "Can not open table2 $!\n";
    chomp $output;
    open (OUT2, ">>$output") or die "Can not open convertion file $!\n";
    our %HM=();
    our $compn=0;
    #our $sugestedafg=0;
    #our $totalR=0;
    while (my $line=<IN1>) {
        chomp $line;
        my @colunms = split(/\t/, $line);
		my $ncolunms = scalar (@colunms);
        my ($INDV1, $INDV2, $PRV) = split(/\t/, $line);
        $HM{$INDV1}{$INDV2} = $PRV;
        $HM{$INDV1}{$INDV1} = 0;
        $HM{$INDV2}{$INDV2} = 0;
        $HM{$INDV2}{$INDV1} = $PRV;
    	#$totalR=$totalR+$PRV;
    	$compn=$compn+1;
    	#if ($INDV1==() or $INDV2==() or $PRV==()){
    	if ($ncolunms != 3){
    	die "Pairwise relatedness table format error at line $compn\n";
    	}
    	#unless($PRV ~~ -1..1){
    	#print "$PRV\n";
    	if ($PRV < -1 or $PRV > 1 or $PRV =~ /[a-zA-Z]/){
    	die "Pairwise relatedness table format error at line $compn, relatedness values should be between -1 and 1\n";
    	}
    }
    #$sugestedafg=$totalR/$compn;
    close IN1;
    our @coln=();
    our @names=<IN2>;
    our $indin=0;
    print OUT2 "\t\t\t";
    foreach my $line0 (@names){
        chomp $line0;
        my @colunms2= split(/\t/, $line0);
		my $ncolunms2=scalar (@colunms2);
        my ($IND0,$SEX0,$IR0)= split(/\t/, $line0);
        print OUT2 "$IND0\t";
        $indin=$indin+1;
        #if ($INDV1==() or $INDV2==() or $PRV==()){
        if ($ncolunms2!=3){
    	die "Internal relatedness table format error at line $indin\n";
    	}
    	#unless($IR0 ~~ -1..1){
    	if ($IR0 < -1 or $IR0 > 1 or $IR0 =~ /[a-zA-Z]/){
    	die "Internal relatedness table format error at line $indin, relatedness values should be between -1 and 1\n"; 
    	}
    	#unless($SEX0 ~~ ["M","F"]){
    	unless($SEX0 eq "M" or $SEX0 eq "F"){
    	die "Internal relatedness table format error at line $indin, sex should be specify as M for males or F for females\n"; 
    	}
    }
    print OUT2 "\n";
    foreach my $line1 (@names){
        chomp $line1;
        my ($IND1,$SEX1,$IR1)= split(/\t/, $line1);
        print OUT2 "$SEX1\t$IR1\t$IND1\t";
        #print "$SEX\t$IR\t$IND1\t";
        push (@coln, $IND1);
        foreach my $line2 (@names){
            chomp $line2;
            my ($IND2,$SEX2,$IR2)= split(/\t/, $line2);
            print OUT2 "$HM{$IND1}{$IND2}\t";
            #print "$HM{$IND1}{$IND2}\t";
        }
        print OUT2 "\n";
        #print "\n";
    }
    close OUT2;
    close IN2;
    print "Matrix created in $output\n";
    $directory=$output;
    chomp $directory;
    
}
else {
    chomp $directory;
}
#print "Matrix created\n";
#print "$dirout\n";
our $loops=0;
print "I am here\n";
{LOOPY: if ($loops==1){
	$THI=$THI-(sqrt(($THI*0.1)**2));
	$THG=$THG-(sqrt(($THG*0.1)**2));
	$THIM=$THIM-(sqrt(($THIM*0.1)**2));
	$THIF=$THIF-(sqrt(($THIF*0.1)**2));
	$mingaver=$mingaver+(sqrt(($mingaver*0.05)**2));
	print "To improve the results we reduced:  MPR to $THI , MARF to $THG, MPRM to $THIM, MPRF to $THIF, and MARFG to $mingaver\n";
	}
	elsif ($loops==2){
	$THI=$THI+(sqrt(($THI*0.02)**2));
	$THG=$THG+(sqrt(($THG*0.02)**2));
	$THIM=$THIM+(sqrt(($THIM*0.02)**2));
	$THIF=$THIF+(sqrt(($THIF*0.02)**2));
	print "To improve the results we increment:  MPR to $THI , MARF to $THG, MPRM to $THIM, MPRF to $THIF, and MARFG to $mingaver\n";
	}
open (IN, "<$directory") or die "Can not open inputfile $!\n";
open (OUT, ">>$dirout") or die "Can not open outputfile $!\n";
chomp $nfg;
chomp $nM;
chomp $nF;
chomp $THIR;
chomp $THI;
chomp $THG;
chomp $THIRM;
chomp $THIRF;
my $SF=0;
my $SM=0;
our @matrix=();
our @bir=();
my $bir=0;
#my $linesc=0;
while (my $line =<IN>){
    my @val=split (/\t/,$line);
    push @matrix, [@val];
    #print "$val[0]\t$val[1]\n";
    if ($bir > 0){
    	if ($val[0] !~ /[FM]/){
    die "Pairwise relatedness matrix format error at line $bir, sex should be specify as M for males or F for females\n";
    }
    	if ($val[1] < -1 or $val[1] > 1 or $val[1] =~ /[a-zA-Z]/){
    die "Pairwise relatedness matrix format error at line $bir, internal relatedness values should be between -1 and 1\n";
    }
    }
    if ($val[0] eq "F"){
        $SF=$SF+1;
        if ($val[1]>$THIRF){
            push (@bir, $bir);
        }
    }
    elsif ($val[0] eq "M"){
        $SM=$SM+1;
        if ($val[1]>$THIRM){
            push (@bir, $bir);
        }
    }
    
    $bir=$bir+1;
}
#print "@matrix[1]->[3]\n";
close IN;
our @FA= (1..$SF);
our @MA= ($SF+1..$SF+$SM);
#print "@FA\n";
#print "@MA\n";
{CLEAN_LOOP:foreach my $bele (@bir){
    for (my $find=0;$find<$SF;$find++){
        if ($FA[$find] eq $bele){
            #print "$FA[$find]\t$bele\n";
            splice(@FA, $find, 1);
            #print "@FA\n";
            next CLEAN_LOOP;
        }
    }
    for (my $mind=0;$mind<$SM;$mind++){
        if ($MA[$mind] eq $bele){
            #print "$MA[$mind]\t$bele\n";
            splice(@MA, $mind, 1);
            next CLEAN_LOOP;
        }
    }
}
}
#print "@FA\n";
#print "@MA\n";
our @AC=();
use Math::Combinatorics;
{
    my @FC=();
    my @MC=();
    my $FC = Math::Combinatorics->new(count => $nF, data => [(@FA)],);
FEMALE_LOOP:while(my @FCN = $FC->next_combination){
    
    my $FCf= join("\n", map { join " ", @$_ } combine (2,@FCN));
    my @SFC=split (/\n/,$FCf);
    foreach my $SFC (@SFC){
        my @coorf=split (/ /,$SFC);
        my $coorf1=$coorf[0];
        my $coorf2=$coorf[1]+2;
        my $frelv=$matrix[$coorf1]->[$coorf2];
        if ($frelv>$THIF and $frelv <= 1){
            next FEMALE_LOOP;
        }
        elsif ($frelv < -1 or $frelv > 1 or $frelv =~ /[a-zA-Z]/){
        die "Pairwise relatedness matrix format error, relatedness between samples $coorf1 and $coorf2  should be between -1 and 1\n";
		}
		}
    #else {
    push (@FC, "@FCN\n");
    #		}
    #}
}
    my $MC = Math::Combinatorics->new(count => $nM, data => [(@MA)],);
MALE_LOOP:while(my @MCN = $MC->next_combination){
    my $MCf= join("\n", map { join " ", @$_ } combine (2,@MCN));
    my @SMC=split (/\n/,$MCf);
    foreach my $SMC (@SMC){
        my @coorm=split (/ /,$SMC);
        my $coorm1=$coorm[0];
        my $coorm2=$coorm[1]+2;
        my $mrelv=$matrix[$coorm1]->[$coorm2];
        if ($mrelv>$THIM and $mrelv<= 1){
            next MALE_LOOP;
        }
        elsif ($mrelv < -1 or $mrelv > 1 or $mrelv =~ /[a-zA-Z]/){
        die "Pairwise relatedness matrix format error, relatedness between samples $coorm1 and $coorm2  should be between -1 and 1\n";
		}
		}
    #else {
    push (@MC, "@MCN\n");
    #		}
    #}
}
    foreach my $FeC (@FC){
        chomp ($FeC);
        foreach my $MeC (@MC){
            chomp ($MeC);
            push (@AC, $FeC." ".$MeC);
        }
    }
}
#print "$AC[1]\n";
my $Npospart=scalar (@AC);
my $times0=0;
our $progress0 = 0;
print "There are $Npospart possible parties\n";
our %GFI=();
our %GFIS=();
{ROOT_LOOP:foreach my $AC(@AC){
    $times0=$times0+1;
    $progress0 = (($times0/$Npospart)*100);
    if ((int(($progress0 * 100000.0) + 0.5)) % 500000 == 0) {
        #Wx::LogMessage("Selecting best parties of $Npospart\t\t$progress0 %% progress");
    }
    my $sum=0;
    my $sumS=0;
    my $ncf=0;
    my @WC=split (/ /,$AC);
    my $SC= join("\n", map { join " ", @$_ } combine (2,@WC));
    my @SC=split (/\n/,$SC);
    foreach my $SeC (@SC){
        my @coor=split (/ /,$SeC);
        my $coor1=$coor[0];
        my $coor2=$coor[1]+2;
        my $coor3=$coor[1];
        my $sex1=$matrix[$coor1]->[0];
        my $sex2=$matrix[$coor3]->[0];
        my $relv=$matrix[$coor1]->[$coor2];
        if ($relv < -1 or $relv > 1 or $relv =~ /[a-zA-Z]/){
        die "Pairwise relatedness matrix format error, relatedness between samples $coor1 and $coor2  should be between -1 and 1\n";
		}
        if ($relv>$THI and $sex1 ne $sex2){
            next ROOT_LOOP;
        }
        else {
            $sum=$sum+$relv;
            if ($sex1 ne $sex2){
                $sumS=$sumS+$relv;
                $ncf=$ncf+1; 
                #print "$sumS\t$ncf\n";
            }
        }
    }
    my $nsc=scalar(@SC);
    my $aver=sprintf("%.4f",$sum/$nsc);
    my $aves=sprintf("%.4f",$sumS/$ncf);
    if ($THSG==()){
        if ($aver<$THG){
            $GFI{$AC}=$aver;
            $GFIS{$AC}=$aves;
            #print "$GFI{$AC}\n";
        }
    }
    elsif ($THG==()){
        if ($aves<$THSG){
            $GFI{$AC}=$aver;
            $GFIS{$AC}=$aves;
            #print "$GFI{$AC}\n";
        }
    }
    else{
        if ($aves<$THSG and $aver<$THG){
            $GFI{$AC}=$aver;
            $GFIS{$AC}=$aves;
        }
    }
}
}
my $Nposible=scalar (keys %GFI);
print "$Nposible parties selected\n";
use Array::Utils qw(:all);
my @DATA=();
my %da_c=();
foreach my $str_line (sort keys%GFI){
    push @DATA,$str_line;
    my @dum = split(/\s+/,$str_line);
    $da_c{$_}++ foreach @dum;
}

if (scalar(keys%da_c) < ($nfg*($nM+$nF)) and $auto eq "n"){
    die "Not enough parties for selceting groups, please change parameters (IR/PR/AR)\n";
}
elsif (scalar(keys%da_c) < ($nfg*($nM+$nF)) and $auto eq "y"){
						$loops=2;
                        goto LOOPY;    
}
my %results=();
my %resultsS=();
{
    
    my $Nposcom = choose($Nposible,$nfg);
    print "There is $Nposcom possible combinations\n";
    my $times=0;
    my $progress=0;
    our $famgroups=0;
    our $secfmgroups=0;
    my %store_comp=();
    
    foreach my $Line1(@DATA){
        my @set1 = split(/\s+/,$Line1);
        foreach my $Line2(@DATA){
            my @set2 = split(/\s+/,$Line2);
            my $set_count = scalar(intersect(@set1,@set2));
            if ($set_count==0){
                $store_comp{$Line1}{match}{$Line2}=1;
            }
        }
    }
use MCE;
LOOPY2:if ($loops==3){
	$mingaver=$mingaver+(sqrt(($mingaver*0.01)**2));
	print "To improve the results we increment:  MARFG to $mingaver\n";
	}
LOOP1:foreach my $l1(sort keys%store_comp){
        my @sub_set1 = split(/\s+/,$l1);
        my $d_l1 = $l1;
        my %fin_cmp=();
        $fin_cmp{$l1}=1;
        my $gsum=0;
        my $gsumS=0;
        $times=$times+1;
        use bignum;
        #$progress=(($times/scalar(keys%store_comp))*100);
        #print "$Nposcom\t$progress\n";
        #if ($progress>1 and (int(($progress * 1000000000) + 0.5)) % 500000000 == 0) {
            #Wx::LogMessage("Selecting best combination of $Nposcom\t\t$progress %% progress");
        #}
        my $tot_cand = scalar(@sub_set1);
        
        foreach my $l2(sort keys%{$store_comp{$d_l1}{match}}){
            my @sub_set2 = split(/\s+/,$l2);
            my $sub_count = scalar(intersect(@sub_set1,@sub_set2));
            if($sub_count==0){
                push @sub_set1,@sub_set2;
                $fin_cmp{$l2}=1;
                #my $testnumber=scalar(@sub_set1);
                #my $test2n=($nfg*$tot_cand);
                #print "$testnumber\t$test2n\n";
                if (scalar(@sub_set1)== ($nfg*$tot_cand)){
                    my @TGF=();
                    foreach my $STGF(sort keys%fin_cmp){
                        push @TGF,$STGF;
                        my $faver = $GFI{$STGF};
                        my $faverS = $GFIS{$STGF};
                        $gsum = $gsum+$faver;
                        $gsumS = $gsumS+$faverS;
                    }
                    
                    my $gaverS = sprintf("%.4f",$gsumS/$nfg);
                    our $gaver = sprintf("%.4f",$gsum/$nfg);
                    #print "$gaver\t$gaverS\t$mingaver\n";
                    if ($gaver<=$mingaver){
                        $famgroups = $famgroups+1;
                        #print "$gaver\t$mingaver\n";
                        $mingaver=$gaver;
                        $results{$famgroups}{fam}{$_}=1 foreach @TGF;
                        $resultsS{$famgroups}{fam2}=$gaverS;
                        $resultsS{$famgroups}{fam1}=$gaver;
                        print "$famgroups bacchanals had passed your filters\n";
                        if ($famgroups > 2 and $auto eq "y"){
                        $loops=1;
                        goto LOOPY;
                        }
                        elsif ($famgroups > 3 and $auto eq "n"){
                        print "Too many possible bacchanals, we recomend you to reduce your tresholds by 5%\n";
                        $self->Close(1); 
                    }
                    elsif ($gaver>$mingaver){
                        $secfmgroups =$secfmgroups+1;
                    }
                }
                elsif (scalar(@sub_set1)>($nfg*$tot_cand)){
                    goto LOOP1;
                }
            }
            else{
                next;
            }
        }
        
        
        
    }
    }
}
if ($famgroups==0){
    if($secfmgroups==0 and $auto eq "n"){
        print "0 bacchanal passed your filters, please relax your criteria\n";
    }
    elsif($secfmgroups==0 and $auto eq "y"){
    $loops=2;
    goto LOOPY;    
    }
    elsif($secfmgroups>0 and $auto eq "n"){
        print "$secfmgroups bacchanals did not passt your min afg threshold, increment it by 0.01\n"
    }
    elsif($secfmgroups>0 and $auto eq "y"){
    $loops=3;
    goto LOOPY2;    
    }
}
elsif ($famgroups>0){
    print "Best combinations selected ans saved in $dirout\n";
    #print "@BGF\n";
    $NFGPS=0;
        foreach my $FOUT(sort keys %results){
        #print "$FOUT\n";
        $NFGPS=$NFGPS+1;
        my @BGF=();
        print OUT "These are the tresholds used for this run:\nMax Pair relatedness=$THI, Max Pair Relatednes Males = $THIM, Max Pair Relatednes Females = $THIF, Max Average Related within Party = $THG,  Max Average Related Between Couples within Party = $THSG, and Max Average Relatedness within Bacchanal = $mingave\n\nSelected Bacchanal number $NFGPS:\n"; 
        print OUT "Average relatedness for all $nfg parties = $resultsS{$FOUT}{fam1}/$resultsS{$FOUT}{fam2}\n\n";
        push @BGF,$_ foreach keys%{$results{$FOUT}{fam}};
        	$NFPS=0;
        foreach my $BFG (@BGF){
            $NFPS=$NFPS+1;
        	print OUT "Party $NFPS in bacchanal $NFGPS\n";
            print OUT "$GFI{$BFG}/$GFIS{$BFG}\t";
            my @F=split (/ /,$BFG);
            foreach my $ind (@F){
                print OUT "$matrix[$ind]->[2]\t";
            }
            print OUT "\n";
            foreach my $ind2 (@F){
                print OUT "$matrix[$ind2]->[2]\t";
                foreach my $ind3 (@F){
                    my $seccoor=$ind3+2;
                    print OUT "$matrix[$ind2]->[$seccoor]\t";
                }
                print OUT "\n";
            }
            print OUT "@F\n\n";
        }
    print OUT "\n";
    }
}
}
close OUT;

sub choose{
    my ($n,$k)=@_;
    my ($result, $j)=(1,1);
    return 0 if $k>$n || $K<0;
    $k=($n-$k) if ($n-$k)<$k;
    while ($j<=$k){
        $result *=$n--;
        $result /=$j++;
    }
    return $result;
}
